/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    int i,j=1,n,k=1,m=2,p=0;
    cout<<"Enter the number";
    cin>>n;
    for(i=n;i>=1;i--)
    {
        
        for(j=1;j<=i;j++)
        {
            cout<<k;
            k=k+2;
        }
        cout<<endl;
        k=(k+p)-8;
        p=p+2;
    }

    return 0;
}
